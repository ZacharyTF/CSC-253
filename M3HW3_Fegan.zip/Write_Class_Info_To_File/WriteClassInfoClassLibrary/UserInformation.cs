﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriteClassInfoClassLibrary
{
    public static class UserInformation
    {
        public static List<InfoProps> LoadInfoList(string firstName, string middleName, string lastName, int age)
        {
            // Makes a new list to hold the user's information
            List<InfoProps> users = new List<InfoProps>();

            // This list contains the user's information
            InfoProps user1 = new InfoProps(firstName, middleName, lastName, age);

            // This adds that information to the list.
            users.Add(user1);

            return users;
        }
    }
}
