﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriteClassInfoClassLibrary
{
    public class InfoProps
    {
        // Fields for first name, last name, and age
        private string _firstName;
        private string _lastName;
        private int _age;

        // Default constructor
        public InfoProps()
        {
            FirstName = "";
            MiddleName = "";
            LastName = "";
            Age = 0;
        }

        // Constructor with parameters
        public InfoProps(string firstName, string middleName, string lastName, int age)
        {
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            Age = age;
        }

        // First name Property
        public string FirstName
        {
            get { return _firstName;  }
            set { _firstName = value; }
        }

        // Last name property
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        // Age property
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        // Middle name autoProperty
        public string MiddleName { get; set; }

        public void AddAge(int input)
        {
            _age += input;
        }

        public void AddAge(string input)
        {
            int num;

            if (int.TryParse(input, out num))
            {
                _age += num;
            }
            else
            {
               string ageMessage = "Enter a valid number!";
            }
        }
    }
}
