﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WriteClassInfoClassLibrary
{
    public static class InfoWriter
    {
        public static string WriteToFile(List<InfoProps> users)
        {
            // Variable used to hold as the file
            StreamWriter outputFile;
            try
            {
                // This opens the file
                outputFile = File.CreateText("UserInformation.csv");

                // using a for-each loop to write all the information in the file
                foreach (InfoProps user in users)
                {
                    // This is the format that the information will be writen in the file  
                    outputFile.WriteLine($"{user.FirstName},{user.MiddleName},{user.LastName},{user.Age}");
                }

                // This closes the file
                outputFile.Close();

                // returns this message if the information was saved successfully
                return "Saved!";
            }
            catch (Exception ex)
            {
                // variable that is used to hold the erorr message
                string erorrMessage = ex.Message;

                // returns erorrmessage if the program could not find the file
                return erorrMessage;
            }
        }
    }
}
