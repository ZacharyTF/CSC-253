﻿using System;

namespace WriteInfoClassLibrary
{
    public class Class1
    {
    }
}
