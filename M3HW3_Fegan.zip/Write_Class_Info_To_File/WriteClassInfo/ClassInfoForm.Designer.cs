﻿
namespace WriteClassInfo
{
    partial class ClassInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveInfoButton = new System.Windows.Forms.Button();
            this.titleLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.nameTitleLabel = new System.Windows.Forms.Label();
            this.middleNameTitleLabel = new System.Windows.Forms.Label();
            this.lastNameTitleLabel = new System.Windows.Forms.Label();
            this.ageTitleLable = new System.Windows.Forms.Label();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // saveInfoButton
            // 
            this.saveInfoButton.Location = new System.Drawing.Point(12, 183);
            this.saveInfoButton.Name = "saveInfoButton";
            this.saveInfoButton.Size = new System.Drawing.Size(80, 27);
            this.saveInfoButton.TabIndex = 0;
            this.saveInfoButton.Text = "Save";
            this.saveInfoButton.UseVisualStyleBackColor = true;
            this.saveInfoButton.Click += new System.EventHandler(this.saveInfoButton_Click);
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(12, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(112, 13);
            this.titleLabel.TabIndex = 1;
            this.titleLabel.Text = "Enter your information:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(172, 36);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(142, 20);
            this.firstNameTextBox.TabIndex = 2;
            // 
            // nameTitleLabel
            // 
            this.nameTitleLabel.AutoSize = true;
            this.nameTitleLabel.Location = new System.Drawing.Point(46, 39);
            this.nameTitleLabel.Name = "nameTitleLabel";
            this.nameTitleLabel.Size = new System.Drawing.Size(106, 13);
            this.nameTitleLabel.TabIndex = 3;
            this.nameTitleLabel.Text = "Enter your first name:";
            // 
            // middleNameTitleLabel
            // 
            this.middleNameTitleLabel.AutoSize = true;
            this.middleNameTitleLabel.Location = new System.Drawing.Point(46, 75);
            this.middleNameTitleLabel.Name = "middleNameTitleLabel";
            this.middleNameTitleLabel.Size = new System.Drawing.Size(120, 13);
            this.middleNameTitleLabel.TabIndex = 4;
            this.middleNameTitleLabel.Text = "Enter your middle name:";
            // 
            // lastNameTitleLabel
            // 
            this.lastNameTitleLabel.AutoSize = true;
            this.lastNameTitleLabel.Location = new System.Drawing.Point(46, 107);
            this.lastNameTitleLabel.Name = "lastNameTitleLabel";
            this.lastNameTitleLabel.Size = new System.Drawing.Size(106, 13);
            this.lastNameTitleLabel.TabIndex = 5;
            this.lastNameTitleLabel.Text = "Enter your last name:";
            // 
            // ageTitleLable
            // 
            this.ageTitleLable.AutoSize = true;
            this.ageTitleLable.Location = new System.Drawing.Point(46, 139);
            this.ageTitleLable.Name = "ageTitleLable";
            this.ageTitleLable.Size = new System.Drawing.Size(79, 13);
            this.ageTitleLable.TabIndex = 6;
            this.ageTitleLable.Text = "Enter your age:";
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(172, 72);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(142, 20);
            this.middleNameTextBox.TabIndex = 7;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(172, 104);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(142, 20);
            this.lastNameTextBox.TabIndex = 8;
            // 
            // ageTextBox
            // 
            this.ageTextBox.Location = new System.Drawing.Point(172, 136);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(142, 20);
            this.ageTextBox.TabIndex = 9;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(234, 183);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(80, 27);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 222);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.ageTitleLable);
            this.Controls.Add(this.lastNameTitleLabel);
            this.Controls.Add(this.middleNameTitleLabel);
            this.Controls.Add(this.nameTitleLabel);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.saveInfoButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button saveInfoButton;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label nameTitleLabel;
        private System.Windows.Forms.Label middleNameTitleLabel;
        private System.Windows.Forms.Label lastNameTitleLabel;
        private System.Windows.Forms.Label ageTitleLable;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.Button exitButton;
    }
}

