﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WriteClassInfoClassLibrary;
using System.IO;

/**
* 09-20-2021
* CSC 253
* zachary Fegan
* This program will demonstrate how to write and save data to a file while using classes.
*/


namespace WriteClassInfo
{
    public partial class ClassInfoForm : Form
    {
        public ClassInfoForm()
        {
            InitializeComponent();
        }

        private void saveInfoButton_Click(object sender, EventArgs e)
        {
            // Make a new list to hold the user's information
            List<InfoProps> users = new List<InfoProps>();

            // Get the user's first name
            string firstName = firstNameTextBox.Text;

            // Get the user's middle name
            string middleName = middleNameTextBox.Text;

            // Get the user's last name
            string lastName = lastNameTextBox.Text;

            // Get the user's age.
            int age = int.Parse(ageTextBox.Text);

            // Pass the information from the textboxes to the list
            users = UserInformation.LoadInfoList(firstName, middleName, lastName, age);

            // Variable that is used to hold the message to display to the user.
            string message = InfoWriter.WriteToFile(users);

            // Dispaly if the information was saved or not.
            MessageBox.Show(message);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the form
            this.Close();
        }
    }
}
